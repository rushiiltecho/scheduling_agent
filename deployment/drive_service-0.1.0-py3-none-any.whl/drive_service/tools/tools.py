from google.adk.tools.application_integration_tool.application_integration_toolset import ApplicationIntegrationToolset
# from .tools_instructions import JIRA_TOOLS_INSTRUCTIONS
from google.adk.auth.auth_credential import AuthCredential, AuthCredentialTypes, HttpAuth, HttpCredentials
import json

jira_tool = ApplicationIntegrationToolset(
    project="proposal-auto-ai-internal",  #Replace with GCP project
    location="us-central1",  #Replace with location of the connection
    connection="jira-cloud-poc-conn",  #Replace with connection name
    entity_operations = {
        "Projects": ["LIST", "GET", "CREATE", "UPDATE"],
        "Issues": ["LIST", "GET", "CREATE", "UPDATE"],
        "IssueTransition": ["LIST", "GET", "CREATE", "UPDATE"],
        "Comments": ["LIST", "GET", "CREATE", "UPDATE"]
    },
    # auth_credential=AuthCredential(
    #     auth_type=AuthCredentialTypes.HTTP,
    #     http=HttpAuth(
    #         scheme="bearer",
    #         credentials=HttpCredentials(token="ya29.a0AW4Xtxhf58ETLBXAXO7VzNugwsjK9d3tzYR9TjhThjFvjPKz2iKU5W3lbOxg2NKihTK0Ri1mTFX1vPxMxlFDfUVjCWXacWfPDtXZP9ayqAChA1IaqVXEYaEl7gi9UIzsHOs7HAUzOVjIvzzEdYOsVkKMym5oluBOmcQTBuK-u28pz04aCgYKAV8SARcSFQHGX2MihmCoGU7fM24ws1U_UPNafA0182"),
    #     ),
    # )
    triggers=["api_trigger/jira_vertex_ai_poc_API_1"],
    service_account_json=json.dumps({
        "type": "service_account",
        "project_id": "proposal-auto-ai-internal",
        "private_key_id": "cc6030ae00e9eb46ecb7f19ccf40c6760cc1af8e",
        "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCVDRTctCbTlhOP\nrkr1gqNEHTeUZphm60u7FGqSL/cHGh5UJIwYku/DNVZO55I2QaUtM5wTZ8ulturg\nLFo/8kwMWB/+V8YNZLnGznKtoHSHsgKRmfJkSpQPsIGJFUwLZFnLxibc7RsrAOod\nlb24M/1WnTtJI52HTM3sG3ExVDkLPCb7ulTHyjRM0xqBsND14eJ1b6KDSAItZKlb\nCDS2T8+X3YBjahd3aJt6jPPUrWzsSkpLB4OwUyOvuadmsOEfa8eNyV1QpnTdq9s+\nu7iB5BbFJ7xnxCHWLfjOpEFy87J56EyvjhPc2wvBVdsnIpyIPfZskYpAipAbN6in\n4t4q0mLlAgMBAAECggEADP+wj5Tog/BlMVUmdWXYvkJ8C+WsqeEgYCbmKmyjcwuc\nlIMBcs0xuskGh2gbsL6l3JzRIkIdmQysTDOiBUyoxDTVSXW3MIjVyNhNWQYS05i7\nL56I7KUyZ3HhwiZI1P+B80sLLZ5CDcyNHlpmSs/B6tFYj8ba4KdamBpGk2JAfVG2\nDaAghkHVGzDDPuNUFw1hq3zqa3S/O7bJ9jV3a/knBKuC3q2L5rGAJROegVnMP/ja\nl4XKcqJPwlMTUayopYDSSjTApjvmMz2IyRJ0mPEn+kneBkELRgzqJiY/y7tC2C7b\nCjjnm5mWNRQLLJscmE6PL+ebeJC80mtqDe5WzsuZcQKBgQDLJLU4kt+sOjae1mx5\nsD7V7A7CMib+svjtSskQ0fB7eUj/9Iekl0QTDMsT8ZRkSqBYyFHTtYSEcxupuyvv\n9bcH4QGV9/cuhVO9E/KXEj1824PgJq/r4JdTLts+NE7iVxVLgxYMzr9sllN/1pq7\nIFyMy7Jv6mU+/A/dBaUz/SwumQKBgQC71U9SQGlLcqAi6PCsW1yPqqdnKhYqcpqZ\nmOfWc7iS8jD/c1KUAoBcVDzA6nPGVFnPc/Tdn+Sp6cjZVW7YkNCvUz4INCIqUoiJ\nApNOqB7HFhoA7qOVeIZmx74tAz/DJjgnZh3fNrlh6N1kq0kv7VloFbG8VgCGy8ov\nO3lQotkCLQKBgQCeOqZpPYW5WdKHoA74Lf6Tk/3e5z+WbgMUmYbJciz1j//7VhV9\nb1FX4UQg8a+a+sGwxb9uvtlMbXhjmWXcz7BUE7+vd2hyNOmHwgzX/R4lrbonkxq+\nCL71zO56ojW7eQcePSmkqjlSNDkvvxHgpZFRHayMHa/lAmK8zpPiTdXnKQKBgBG9\nrgZIyykzJGjns4O0BWQUbEdUNE/CD1QemxcoSvCmK3aVP+F28wTFeA+IlXLQGMN9\nYk1kgsaBrFTKuvN9ihhlNmCz+94feYHnWl59hpqrPb2EzLKbdaZTi2TY/7bA72DZ\nRk0E8DGNOwv9GaaLNnycP/NX9CjHKsuXRHgXSYPpAoGBAJQOr+klW5ogC2koQK4b\nwlxlbxYyLI3iSlflYGcgKDdlanWa0acU2fT+AFWospjqF59SUzsyLeyAceTdyt0e\n9ZhXX167FMl5nYMeD/YXLzx6sLbW44eouEbLU8q6bL5QvuQKuzPrumCL/vUM8K6d\nj3DZNwVj52hGDETjlhfudRPS\n-----END PRIVATE KEY-----\n",
        "client_email": "agentspace-poc@proposal-auto-ai-internal.iam.gserviceaccount.com",
        "client_id": "107796353242384341482",
        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
        "token_uri": "https://oauth2.googleapis.com/token",
        "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
        "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/agentspace-poc%40proposal-auto-ai-internal.iam.gserviceaccount.com",
        "universe_domain": "googleapis.com"
        }
    ),
)